from resources.lib.app import run

run()
