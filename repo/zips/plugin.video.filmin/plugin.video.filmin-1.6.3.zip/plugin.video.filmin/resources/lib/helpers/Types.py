class Types:
    videos = ("short", "film", "episode")
    folders = ("serie", "season")
