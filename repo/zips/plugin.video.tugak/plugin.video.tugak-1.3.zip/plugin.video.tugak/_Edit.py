import xbmcaddon

MainBase = 'http://bit.ly/2FCdP2F'
addon = xbmcaddon.Addon('plugin.video.tugak')